package inheritanceConcept;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		IIT iit = new IIT();
		iit.doPlacements();
		iit.checkExams();
		iit.doTeaching();
		System.out.println("--------------");
		IIM iim = new IIM();
		iim.doPlacements();

	}

}
