package inheritanceConcept;

public class WEO {
	
	public void doTeaching() {
		System.out.println("WEO -- Teaching");
	}
	
	public void enrollStudents() {
		System.out.println("WEO -- enroll students");
	}

}
